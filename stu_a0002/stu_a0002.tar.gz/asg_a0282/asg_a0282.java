class AsgA0282
{
public static void main(String args[])
{
int i,j;
for(i=5;i>=0;i--)
{
for(j=0;j<i*2-1;j++)
{
System.out.print("*");
}
System.out.println();
}
}
}
