class asg_a0284
public static void main(String args[])
{
int i,j,k;
for(i=0;i<7;i++)
{
//System.out.println();
for(j=i;j<8;j++)
{
System.out.print(" ");
}
for(k=0;k<8;k++)
{
System.out.print("*");
}
System.out.println();
}
}
}

   
