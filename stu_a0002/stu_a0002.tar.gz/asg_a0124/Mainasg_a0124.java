class Mainasg_a0124
{
public static void main(String args[])
{
asg_a0124 temp=new asg_a0124();
System.out.println(temp.my_minimum(10,5,20));
}
}
