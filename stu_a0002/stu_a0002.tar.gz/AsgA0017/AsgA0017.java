class AsgA0017
{
 public static void main(String args[])
  {
   float CP,SP,profit=0,profitper=0;
   CP=1000;
   SP=1020;
  if (SP>CP)
   {
    profit=SP-CP;
    profitper=(profit/CP)*100;
     
   } 
    System.out.println("Profit is="+ profit);
    System.out.println("Profit Percentage is="+ profitper);
  }


}
