class AsgA0031
{
  public static void main(String arg[])
    {
     float gross_salary;
     float bsp=20000;
     float da=bsp*10/100;
     float hra=bsp*15/100;
     gross_salary=bsp+da+hra;
     System.out.println("GrossSalary:"+ gross_salary);
     }

}
