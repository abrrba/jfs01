
class AsgA0281
{
public static void main(String args[])
{
int i,j,k;
for(i=1;i<5;i++)
{
System.out.println();
for(j=5;j>i;j--)
{
System.out.print(" ");
}
for(k=1;k<=2*i-1;k++)
{
System.out.print("*");
}
}
for(i=5;i>=1;i--)
{
System.out.println();
for(j=5;j>i;j--)
{
System.out.print(" ");
}
for(k=1;k<=2*i-1;k++)
{
System.out.print("*");
}
}

}
}
