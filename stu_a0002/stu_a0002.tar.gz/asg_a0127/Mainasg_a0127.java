public class Mainasg_a0127
{
public static void main(String[] args)
{
asg_a0127 temp=new asg_a0127();
System.out.println(temp.my_floor(-3.4));
}
}

