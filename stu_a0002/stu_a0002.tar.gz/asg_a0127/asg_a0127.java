class asg_a0127
{
public double  my_floor(double num)
{
if(num>0)
{
int num1=(int)num;
int x=num1;
return(x);
}
else if(num<0)
{
int num1=(int)num;
int x=num1-1;
return(x);
}
else
{
return(0);
}
}
}
