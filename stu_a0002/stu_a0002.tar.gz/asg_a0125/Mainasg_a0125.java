public class Mainasg_a0125
{
public static void main(String[] args)
{
asg_a0125 temp=new asg_a0125();
System.out.println(temp.my_ceiling(10.34));
}
}

