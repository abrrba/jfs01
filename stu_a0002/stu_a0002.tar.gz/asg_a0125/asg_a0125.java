class asg_a0125
{
public double  my_ceiling(double num)
{
int num1=(int)num;
int x=num1+1;
return(x);
}
}

