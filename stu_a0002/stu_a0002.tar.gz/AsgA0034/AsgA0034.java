class AsgA0034
  {
    public static void main(String arg[])
   {
     int m=1000000;
     System.out.println("Enter Kilometer");
     double km=1;
     double kms=km*m;
     System.out.println(km+"kilometers="+kms+"in Milimeters");


   }


  }  
