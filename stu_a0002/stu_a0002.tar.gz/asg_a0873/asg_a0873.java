
class AsgA0873
{
public static void main(String args[])
{
String str=new String(" hello world  ");
System.out.println(str.replaceAll("\\s",""));
}
}
