class AsgA0032
  {
    public static void main(String args[])
       {
         int m=1000;
      System.out.println("ENTER KILOMETER");
         double km=1;
         double KmtoM=km*m;
      System.out.println(km+"kilometers"+KmtoM +"in meters");
     
       }


  }  
