class asg_a0278 
{
public static void main(String[] args) 
{
int i, j, k;
for(i=5;i>0;i--)
{
//System.out.println();
for(j=0;j<i;j++)
{
System.out.print("#");
}
for(k=i;k<=5;k++)
{
System.out.print("*");
}
System.out.println();
}
}

}
