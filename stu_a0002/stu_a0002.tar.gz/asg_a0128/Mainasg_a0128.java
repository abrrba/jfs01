public class MainAsgA0128{
public static void main(String argv[])
{
asg_a0128 temp = new asg_a0128();
temp.is_zero(10);
}

}
