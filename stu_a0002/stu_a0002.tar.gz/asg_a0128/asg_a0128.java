public class asg_a0128{
public static boolean is_zero(int number)
{

if(number==0)
{
System.out.println(1);
}
else
{
System.out.println(0);
}
return(false);
}
}
