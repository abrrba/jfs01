class AsgA0033{
public static double convert_kms_to_feet(double num)
{
double c=(num*3280.840);
return(c);
}
}
public class asgA0033{
public static void main(String args[])
{
AsgA0033 obj=new AsgA0033();
System.out.println(Asg_a0033.convert_kms_to_feet(1));
}
}


