class AsgA0036
{
  public static void main(String args[])
    {
       float temp=0;
      System.out.println("Enter temp in farenheit");
       temp=((temp-32)*5)/9;
      System.out.println("Temp in celcious="+temp);



     }




}
