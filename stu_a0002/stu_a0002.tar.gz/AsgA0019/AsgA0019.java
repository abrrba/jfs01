class AsgA0019
{
public static void main(String arg[])
{
 double cir;float m=1;
 cir=2*3.14*m;


System.out.println("Circumference of circle="+ cir);

}

}
